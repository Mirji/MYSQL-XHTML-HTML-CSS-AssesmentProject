<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
// sql to create table
$sql = "CREATE TABLE addcourse3(coursename	varchar(15),coursecode	varchar(9),	practicaltheory	varchar(15),	lecturerhrs	int(11),	practicalhrs	int(11),
totalcredit	int(11),cie	int(11),see	int(11),examduration	int(11)
		
)";
if ($conn->query($sql) === TRUE) 
{
    echo " assigncourse3 Table created successfully";
} 
else 
{
    echo "Error in creating table: "
	. $conn->error;
}
$conn->close();
?>