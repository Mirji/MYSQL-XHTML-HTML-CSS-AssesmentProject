<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
$password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
$sql = "SELECT * FROM addcourse1";
$result = $conn->query($sql);
if ($result->num_rows > 0) 
{
    // output data of each row
    while($row = $result->fetch_assoc())
	{
        echo "Course Name: ". $row["coursename"].
              "Course Code:".$row["coursecode"].
              "Practical/Theory:".$row["practicaltheory"].
             " Lecturer Hours" . $row["lecturerhrs"]. "Practical Hours: " 
		     . $row["practicalhrs"]. "Total credits "
             . $row["totalcredit"]."CIE Max Marks "
                . $row["cie"]."SEE Max Marks "
                . $row["see"]."Exam Duration in minutes "
		. $row["examduration"]."<br>";     
	}
} 
else 
{
    echo "No results found";
}
$conn->close();
?>