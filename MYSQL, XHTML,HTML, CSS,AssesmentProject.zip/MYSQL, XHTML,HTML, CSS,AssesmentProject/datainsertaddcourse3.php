<?php
$servername="localhost";
$username="root";
$password="";
$dbname = "studentdata";
//create connection
$conn = new mysqli ($servername, $username,$password,$dbname);
if($conn->connect_error)
{
die("Connection failed:"

.$conn->connect_error);
}
$sql="INSERT INTO addcourse3 (coursename,coursecode,practicaltheory,lecturerhrs,	practicalhrs,totalcredit,cie,see,examduration)
VALUES('$_POST[coursename]',
'$_POST[coursecode]',
'$_POST[practicaltheory]',
'$_POST[lecturerhrs]',
'$_POST[practicalhrs]',
'$_POST[totalcredit]',
'$_POST[cie]',
'$_POST[see]',
'$_POST[examduration]')";




if($conn->query($sql)===TRUE)
{
echo '<script language="javascript">';
echo'alert("New record created succesfully")';
echo '</script>';
echo "<a href=admindashboard.html.html>Go to AdminDashboard</a>";
}
else
{
echo "Error:".$sql."<br>".$conn->error;
}
$conn->close();
?>
