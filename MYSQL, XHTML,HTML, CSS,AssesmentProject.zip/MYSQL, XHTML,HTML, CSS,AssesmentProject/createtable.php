<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
// sql to create table
$sql = "CREATE TABLE student_details2 (firstname VARCHAR(30) NOT NULL,
password VARCHAR(30) NOT NULL,
confirm_password VARCHAR(30) NOT NULL,
userid VARCHAR(30) NOT NULL, 
email VARCHAR(50) NOT NULL,
contact_no int(10) NOT NULL,
address VARCHAR(60) NOT NULL,
date_of_birth TIMESTAMP,
select_department VARCHAR(20) NOT NULL,
select_user VARCHAR(20) NOT NULL,
reg_date TIMESTAMP,
enter_captcha VARCHAR(6) NOT NULL
)";
if ($conn->query($sql) === TRUE) 
{
    echo " student_details2 Table created successfully";
} 
else 
{
    echo "Error in creating table: "
	. $conn->error;
}
$conn->close();
?>