<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
// sql to create table
$sql = "CREATE TABLE student_details1 (
userid VARCHAR(30) NOT NULL,
password VARCHAR(30) NOT NULL,
confirm_password VARCHAR(30) NOT NULL,
USN INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50),
contact_no int(10) NOT NULL,
address VARCHAR(60) NOT NULL,
date_of_birth TIMESTAMP,
select_department VARCHAR(20) NOT NULL,
select_user VARCHAR(20) NOT NULL,
reg_date TIMESTAMP,
captcha VARCHAR(6) NOT NULL,
enter_captcha VARCHAR(6) NOT NULL
)";
if ($conn->query($sql) === TRUE) 
{
    echo " student_details Table created successfully";
} 
else 
{
    echo "Error in creating table: "
	. $conn->error;
}
$conn->close();
?>