<?php
$servername="localhost";
$username="root";
$password="";
$dbname="studentdata";


$conn=new mysqli($servername,$username,$password,$dbname);


if($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}

$sql="SELECT * FROM sem1PCassignfiles";
$result=$conn->query($sql);


echo "<table border='1' width=40% margin-top=50% align=center>";

 echo " <tr>  
        <td>USN:</td>  
		<td>Name:</td>
        <td>Filename:</td>  		
        </tr>";

if($result->num_rows>0)
{


								  
								while($row=$result->fetch_assoc())
{
    
  
	      
	echo"	  <tr> 
		 
	                                                     
        <td>".$row["usn"]."</td>
		<td>".$row["name"]."</td>
		<td>".$row["filename"]."</td>
		</tr>
        
        
		
";
}
echo "</tble>";
}

else
{
    echo "NO result found";
}
$conn->close();
echo "<br>";
?>


<?php
$servername="localhost";
$username="root";
$password="";
$dbname="studentdata";


$conn=new mysqli($servername,$username,$password,$dbname);


if($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}

$sql="SELECT * FROM sem1DMSassignfiles";
$result=$conn->query($sql);


echo "<table border='1' width=40% margin-top=50% align=center>";

 echo " <tr>  
        <td>USN:</td>  
		<td>Name:</td>
        <td>Filename:</td>  		
        </tr>";

if($result->num_rows>0)
{


								  
								while($row=$result->fetch_assoc())
{
    
  
	      
	echo"	  <tr> 
		 
	                                                     
        <td>".$row["usn"]."</td>
		<td>".$row["name"]."</td>
		<td>".$row["filename"]."</td>
		</tr>
        
        
		
";
}
echo "</tble>";
}

else
{
    echo "NO result found";
}
$conn->close();
echo "<br>";
?>





<?php
$servername="localhost";
$username="root";
$password="";
$dbname="studentdata";


$conn=new mysqli($servername,$username,$password,$dbname);


if($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}

$sql="SELECT * FROM sem1FCOAassignfiles";
$result=$conn->query($sql);


echo "<table border='1' width=40% margin-top=50% align=center>";

 echo " <tr>  
        <td>USN:</td>  
		<td>Name:</td>
        <td>Filename:</td>  		
        </tr>";

if($result->num_rows>0)
{


								  
								while($row=$result->fetch_assoc())
{
    
  
	      
	echo"	  <tr> 
		 
	                                                     
        <td>".$row["usn"]."</td>
		<td>".$row["name"]."</td>
		<td>".$row["filename"]."</td>
		</tr>
        
        
		
";
}
echo "</tble>";
}

else
{
    echo "NO result found";
}
$conn->close();
echo "<br>";
?>




<?php

$servername="localhost";
$username="root";
$password="";
$dbname="studentdata";


$conn=new mysqli($servername,$username,$password,$dbname);


if($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}
$sql="SELECT * FROM sem1PSTAassignfiles";
$result=$conn->query($sql);

echo "<table border='1' width=40% margin-top=50% align=center>";

 echo " <tr>  
        <td>USN:</td>  
		<td>Name:</td>
        <td>Filename:</td>  		
        </tr>";

if($result->num_rows>0)
{


								  
								while($row=$result->fetch_assoc())
{
    
  
	      
	echo"	  <tr> 
		 
	                                                     
        <td>".$row["usn"]."</td>
		<td>".$row["name"]."</td>
		<td>".$row["filename"]."</td>
		</tr>
        
        
		
";
}
echo "</tble>";
}

else
{
    echo "NO result found";
}
$conn->close();
echo "<br>";
?>




<?php
$servername="localhost";
$username="root";
$password="";
$dbname="studentdata";


$conn=new mysqli($servername,$username,$password,$dbname);


if($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}

$sql="SELECT * FROM sem1Webassignfiles";
$result=$conn->query($sql);


echo "<table border='1' width=40% margin-top=50% align=center>";

 echo " <tr>  
        <td>USN:</td>  
		<td>Name:</td>
        <td>Filename:</td>  		
        </tr>";

if($result->num_rows>0)
{


								  
								while($row=$result->fetch_assoc())
{
    
  
	      
	echo"	  <tr> 
		 
	                                                     
        <td>".$row["usn"]."</td>
		<td>".$row["name"]."</td>
		<td>".$row["filename"]."</td>
		</tr>
        
        
		
";
}
echo "</tble>";
}

else
{
    echo "NO result found";
}
$conn->close();
echo "<br>";
?>




<?php
$servername="localhost";
$username="root";
$password="";
$dbname="studentdata";


$conn=new mysqli($servername,$username,$password,$dbname);


if($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}

$sql="SELECT * FROM sem1Unixassignfiles";
$result=$conn->query($sql);


echo "<table border='1' width=40% margin-top=50% align=center>";

 echo " <tr>  
        <td>USN:</td>  
		<td>Name:</td>
        <td>Filename:</td>  		
        </tr>";

if($result->num_rows>0)
{


								  
								while($row=$result->fetch_assoc())
{
    
  
	      
	echo"	  <tr> 
		 
	                                                     
        <td>".$row["usn"]."</td>
		<td>".$row["name"]."</td>
		<td>".$row["filename"]."</td>
		</tr>
        
        
		
";
}
echo "</tble>";
}

else
{
    echo "NO result found";
}
$conn->close();
echo "<br>";
?>