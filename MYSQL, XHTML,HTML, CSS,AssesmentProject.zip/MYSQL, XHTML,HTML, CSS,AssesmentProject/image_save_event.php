<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
if (isset($_POST['submit'])){
$filename=$_FILES["uploadfile"]["name"];
$tempname=$_FILES["uploadfile"]["tmp_name"];
$folder="event/".$filename;
move_uploaded_file($tempname,$folder);
$name=$_POST['name'];


$sql ="insert into addimg_event(name,pick) values('$name','$folder')";

}

if($conn->query($sql)===TRUE)
{
echo"record created succesfully";
}
else
{
echo "Error:".$sql."<br>".$conn->error;
}
$conn->close();
 
?>	