<html>
<body>
<table border=3>
<?php 
$servername = "localhost"; 
$username = "root"; 
$password = "";
$dbname="studentdata";
// Create connection 
$conn = new mysqli($servername, $username, 
                    $password,$dbname); 
// Check connection 
if ($conn->connect_error)  
{ 
    die("Connection failed:"  
 . $conn->connect_error); 
}  
$sql = "select * from student_details2";

$result = $conn->query($sql); 
if ($result->num_rows > 0)  
{ 

echo "<tc><th>";
echo "userid: ";
 echo "</th><th>";
echo "password:";
 echo "</th><th>";
echo "confirm_password:";
echo "</th><th>";
echo "firstname:";
echo "</th><th>";
echo "Email: ";
echo "</th><th>";
echo "mobileno: ";
echo "</th><th>";
echo "address: ";
echo "</th><th>";
echo "date of birth: ";
echo "</th><th>";
echo "register date: ";
echo "</th><th>";
echo "enter captcha: ";
echo "</th></tc>";
    
    // output data of each row 
    while($row = $result->fetch_assoc()) 
 { 
echo "<tr>
 <td>".$row["userid"] ."</td>
 <td>".$row["password"] ."</td>
 <td>".$row["confirm_password"]."</td><td>".
	  
	$row["firstname"]  ."</td><td>".
	
	$row["email"] ."</td><td>".
	
	$row["contact_no"]  ."</td><td>".
	 
	    $row["address"]."</td><td>" .
	  
	  
	
	
	   $row["date_of_birth"] ."</td><td>".

	  $row["reg_date"] ."</td><td>".

	  $row["enter_captcha"] ."</td></tr>"; 
	 


 } 
}  
else  
{ 
    echo "No results found"; 
	} 
$conn->close(); 
?>
</body>
</html>
