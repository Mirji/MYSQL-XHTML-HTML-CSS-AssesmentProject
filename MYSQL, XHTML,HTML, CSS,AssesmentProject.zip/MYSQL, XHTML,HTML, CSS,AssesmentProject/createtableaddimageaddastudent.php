<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
// sql to create table
$sql = "CREATE TABLE addimg_addastudent_2(name varchar(30),emailid varchar(30),usn varchar(12),pick text(60))";
if ($conn->query($sql) === TRUE) 
{
    echo " addimageaddastudent_2 Table created successfully";
} 
else 
{
    echo "Error in creating table: "
	. $conn->error;
}
$conn->close();
?>