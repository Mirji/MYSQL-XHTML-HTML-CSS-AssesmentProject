
<style type="text/css">

.form-style-9{
    max-width: 450px;
    background: #FAFAFA;
    padding: 30px;
    margin: 50px auto;
	
    box-shadow: 1px 1px 25px rgba(0, 0, 0, 0.35);
    border-radius: 10px;
    border: 6px solid #305A72;
}
.form-style-9 ul input[id="inputPassword"]{
 margin-left: 45px 
 }
 .form-style-9 ul select[name="gender"]{
 margin-left: 63px 
 }
 
  .form-style-9 ul select[name="type"]{
 margin-left: 75px 
 }
 



.form-style-9 ul{
    padding:0;
    margin:0;
    list-style:none;
}
.form-style-9 ul li{
    display: block;
    margin-bottom: 10px;
    min-height: 35px;
}
.form-style-9 ul li  .field-style{
    box-sizing: border-box; 
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box; 
    padding: 8px;
    outline: none;
    border: 1px solid #B0CFE0;
    -webkit-transition: all 0.30s ease-in-out;
    -moz-transition: all 0.30s ease-in-out;
    -ms-transition: all 0.30s ease-in-out;
    -o-transition: all 0.30s ease-in-out;

}







</style>




<html>
<body bgcolor="#CCCC99">
<h1 align="center">Submit Assignment</h1>

<p><a href="member.php" class="btn btn-info"><i class="icon-arrow-left icon-large"></i>&nbsp;</a></p>
	          		
	<form class="form-style-9" method="POST" action="save_sem3_DAA_assignments.php" enctype="multipart/form-data">


<ul>
<li>

<label >USN</label>
 <input type="text"  id="name" name="usn" class="field-style field-split align-right" placeholder ="Enter USN" /><br><br>
 <label >Name</label>
 <input type="text"  id="name" name="name" class="field-style field-split align-right" placeholder ="Enter Name" /><br><br>
	
 
	

<label>Filename</label>
 <input type="file" name="uploadfile" class="field-style field-split align-left"  />
	<br><br>


	
	
<button name="submit" type="submit" class="btn btn-success"><i class="icon-save icon-large"></i>&nbsp;Save</button>
		

	

 

</div> </div>
</label>

	</li>
	</ul>
	</body>
	</html>
