<?php
$servername="localhost";
$username="root";
$password="";
$dbname = "studentdata";
//create connection
$conn = new mysqli ($servername, $username,$password,$dbname);
if($conn->connect_error)
{
die("Connection failed:"

.$conn->connect_error);
}
$sql="INSERT INTO student_detailslogin(scode,pwd,cpwd)
VALUES('$_POST[scode]',
'$_POST[pwd]',
'$_POST[cpwd]')";


if($conn->query($sql)===TRUE)
{
echo"New password created succesfully";
}
else
{
echo "Error:".$sql."<br>".$conn->error;
}
$conn->close();
?>
