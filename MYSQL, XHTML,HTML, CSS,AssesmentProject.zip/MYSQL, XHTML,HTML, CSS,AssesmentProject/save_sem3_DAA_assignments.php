<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
if (isset($_POST['submit'])){
$filename=$_FILES["uploadfile"]["name"];
$tempname=$_FILES["uploadfile"]["tmp_name"];
$folder="DAA_Assignments/".$filename;
move_uploaded_file($tempname,$folder);
$name=$_POST['name'];

$sql ="insert into sem3DAAassignfiles(usn,name,filename) values('$_POST[usn]','$name','$folder')";
}

if($conn->query($sql)===TRUE)
{
echo '<script language="javascript">';
echo'alert("New record created succesfully")';
echo '</script>';
echo "<a href=Student_Dashboard.html>Go to StudentDashboard</a>";
}
else
{
echo "Error:".$sql."<br>".$conn->error;
}
$conn->close();
 
?>	