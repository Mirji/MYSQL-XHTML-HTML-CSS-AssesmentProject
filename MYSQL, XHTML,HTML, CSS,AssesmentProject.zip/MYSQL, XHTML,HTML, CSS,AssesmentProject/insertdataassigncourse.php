<?php
$servername="localhost";
$username="root";
$password="";
$dbname = "studentdata";
//create connection
$conn = new mysqli ($servername, $username,$password,$dbname);
if($conn->connect_error)
{
die("Connection failed:"

.$conn->connect_error);
}
$sql="INSERT INTO assigncourse (staffname, subjectname, subjectcode)
VALUES('$_POST[staffname]',
'$_POST[subjectname]',
'$_POST[subjectcode]')";




if($conn->query($sql)===TRUE)
{
echo '<script language="javascript">';
echo'alert("New record created succesfully")';
echo '</script>';
echo "<a href=admindashboard.html.html>Go to AdminDashboard</a>";
}
else
{
echo "Error:".$sql."<br>".$conn->error;
}
$conn->close();
?>
