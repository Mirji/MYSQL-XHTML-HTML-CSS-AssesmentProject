<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
// sql to create table
$sql = "CREATE TABLE student_detailslogin (scode VARCHAR(7) NOT NULL,
pwd VARCHAR(30) NOT NULL,cpwd VARCHAR(30) NOT NULL)";
if ($conn->query($sql) === TRUE) 
{
    echo " student_detailslogin Table created successfully";
} 
else 
{
    echo "Error in creating table: "
	. $conn->error;
}
$conn->close();
?>