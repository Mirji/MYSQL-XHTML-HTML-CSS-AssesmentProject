<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
// sql to create table
$sql = "CREATE TABLE sem1marks1(USN varchar(100),Name VARCHAR(200),PCM1 int,PCM2 int,PCA int,DMSM1 int,DMSM2 int,DMSA int,FCOM1 int,FCOM2 int,FCOA int,
PSTM1 int,PSTM2 int,PSTA int,WEBM1 int,WEBM2 int,WEBA int,PRIMARY KEY(USN))";
if ($conn->query($sql) === TRUE) 
{
    echo " sem1marks1 Table created successfully";
} 
else 
{
    echo "Error in creating table: "
	. $conn->error;
}
$conn->close();
?>