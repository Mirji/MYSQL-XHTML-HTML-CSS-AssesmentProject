<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
// sql to create table
$sql = "CREATE TABLE sem5marks1(USN varchar(100),Name VARCHAR(200),MLM1 int,MLM2 int,MLA int,BDAM1 int,BDAM2 int,BDAA int,AVPM1 int,AVPM2 int,AVPA int,
IOTM1 int,IOTM2 int,IOTA int,MADM1 int,MADM2 int,MADA int,PRIMARY KEY(USN))";
if ($conn->query($sql) === TRUE) 
{
    echo " sem5marks1 Table created successfully";
} 
else 
{
    echo "Error in creating table: "
	. $conn->error;
}
$conn->close();
?>