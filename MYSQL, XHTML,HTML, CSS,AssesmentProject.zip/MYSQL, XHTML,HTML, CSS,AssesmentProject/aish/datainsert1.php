<?php
$servername="localhost";
$username="root";
$password="";
$dbname = "studentdata";
//create connection
$conn = new mysqli ($servername, $username,$password,$dbname);
if($conn->connect_error)
{
die("Connection failed:"

.$conn->connect_error);
}
$sql="INSERT INTO student_details2 (userid,password,confirm_password,firstname,email,contact_no,address,date_of_birth,reg_date,enter_captcha)
VALUES('$_POST[userid]',
'$_POST[password]',
'$_POST[confirm_password]',
'$_POST[firstname]',
'$_POST[email]',
'$_POST[contact_no]',
'$_POST[address]',
'$_POST[date_of_birth]',
'$_POST[reg_date]',
'$_POST[enter_captcha]')";




if($conn->query($sql)===TRUE)
{
echo"New record created succesfully";
}
else
{
echo "Error:".$sql."<br>".$conn->error;
}
$conn->close();
?>
