<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
$password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
$sql = "SELECT * FROM student_details2";
$result = $conn->query($sql);
if ($result->num_rows > 0) 
{
    // output data of each row
    while($row = $result->fetch_assoc())
	{
        echo "userid: ". $row["userid"].
              "password:".$row["password"].
              "confirm password:".$row["confirm_password"].
             " Name " . $row["firstname"]. "email: " 
		     . $row["email"]. "mobile number "
             . $row["contact_no"]."address "
                . $row["address"]."date of birth "
                . $row["date_of_birth"]." Registration Date "
		. $row["reg_date"]. "enter captcha"
                . $row["enter_captcha"]."<br>";     
	}
} 
else 
{
    echo "No results found";
}
$conn->close();
?>