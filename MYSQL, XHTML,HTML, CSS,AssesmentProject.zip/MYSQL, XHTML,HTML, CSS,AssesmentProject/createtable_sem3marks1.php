<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
// sql to create table
$sql = "CREATE TABLE sem3marks1(USN varchar(100),Name VARCHAR(200),CNM1 int,CNM2 int,CNA int,JavaM1 int,JavaM2 int,JavaA int,DAAM1 int,DAAM2 int,DAAA int,
DBMSM1 int,DBMSM2 int,DBMSA int,PythonM1 int,PythonM2 int,PythonA int,PRIMARY KEY(USN))";
if ($conn->query($sql) === TRUE) 
{
    echo " upload Table created successfully";
} 
else 
{
    echo "Error in creating table: "
	. $conn->error;
}
$conn->close();
?>