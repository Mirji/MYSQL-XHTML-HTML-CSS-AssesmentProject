<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
if (isset($_POST['submit'])){
$filename=$_FILES["uploadfile"]["name"];
$tempname=$_FILES["uploadfile"]["tmp_name"];
$folder="addastudent_2/".$filename;
move_uploaded_file($tempname,$folder);
$name=$_POST['name'];
$emailid=$_POST['emailid'];
$usn=$_POST['usn'];

$sql ="insert into addimg_addastudent_2(name,emailid,usn,pick) values('$name','$emailid','$usn','$folder')";

}

if($conn->query($sql)===TRUE)
{
echo"record created succesfully";
}
else
{
echo "Error:".$sql."<br>".$conn->error;
}
$conn->close();
 
?>	