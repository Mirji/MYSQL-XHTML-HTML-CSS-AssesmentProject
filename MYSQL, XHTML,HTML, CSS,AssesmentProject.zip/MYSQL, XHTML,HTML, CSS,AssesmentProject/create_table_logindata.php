<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
// sql to create table
$sql = "CREATE TABLE logindata(Username varchar(100),Password varchar(100),emailid varchar(100),sem varchar(10),PRIMARY KEY(Password))";
if ($conn->query($sql) === TRUE) 
{
    echo " logindata Table created successfully";
} 
else 
{
    echo "Error in creating table: "
	. $conn->error;
}
$conn->close();
?>