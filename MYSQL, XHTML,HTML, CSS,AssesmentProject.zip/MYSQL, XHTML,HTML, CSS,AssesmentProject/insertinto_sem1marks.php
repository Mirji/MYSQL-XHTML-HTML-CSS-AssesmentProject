<?php
$servername="localhost";
$username="root";
$password="";
$dbname = "studentdata";
//create connection
$conn = new mysqli ($servername, $username,$password,$dbname);
if($conn->connect_error)
{
die("Connection failed:"

.$conn->connect_error);
}
$sql="INSERT INTO sem1marks1(USN,Name,PCM1,PCM2,PCA,DMSM1,DMSM2,DMSA,FCOM1,FCOM2,FCOA,PSTM1,PSTM2,PSTA,WEBM1,WEBM2,WEBA)
VALUES('$_POST[USN]',
'$_POST[name]',
'$_POST[pcminor1]',
'$_POST[pcminor2]',
'$_POST[pcassign]',
'$_POST[dmsminor1]',
'$_POST[dmsminor2]',
'$_POST[dmsassign]',
'$_POST[fcominor1]',
'$_POST[fcominor2]',
'$_POST[fcoassign]',
'$_POST[pstminor1]',
'$_POST[pstminor2]',
'$_POST[pstassign]',
'$_POST[webminor1]',
'$_POST[webminor2]',
'$_POST[webassign]')";




if($conn->query($sql)===TRUE)
{
echo"Marks assigned successfully succesfully";
}
else
{
echo "Error:".$sql."<br>".$conn->error;
}
$conn->close();
?>
