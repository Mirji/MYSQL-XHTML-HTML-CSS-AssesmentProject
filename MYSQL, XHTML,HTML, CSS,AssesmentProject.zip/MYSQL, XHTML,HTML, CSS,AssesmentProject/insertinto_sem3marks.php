<?php
$servername="localhost";
$username="root";
$password="";
$dbname = "studentdata";
//create connection
$conn = new mysqli ($servername, $username,$password,$dbname);
if($conn->connect_error)
{
die("Connection failed:"

.$conn->connect_error);
}
$sql="INSERT INTO sem3marks1(USN, Name, CNM1,CNM2,CNA ,JavaM1,JavaM2,JavaA,DAAM1,DAAM2,DAAA ,DBMSM1,DBMSM2,DBMSA,PythonM1,PythonM2,PythonA)
VALUES('$_POST[USN]',
'$_POST[name]',
'$_POST[cnminor1]',
'$_POST[cnminor2]',
'$_POST[cnassign]',
'$_POST[javaminor1]',
'$_POST[javaminor2]',
'$_POST[javaassign]',
'$_POST[daaminor1]',
'$_POST[daaminor2]',
'$_POST[daaassign]',
'$_POST[dbmsminor1]',
'$_POST[dbmsminor2]',
'$_POST[dbmsassign]',
'$_POST[pythonminor1]',
'$_POST[pythonminor2]',
'$_POST[pythonassign]')";




if($conn->query($sql)===TRUE)
{
echo"Marks assigned successfully succesfully";
}
else
{
echo "Error:".$sql."<br>".$conn->error;
}
$conn->close();
?>
