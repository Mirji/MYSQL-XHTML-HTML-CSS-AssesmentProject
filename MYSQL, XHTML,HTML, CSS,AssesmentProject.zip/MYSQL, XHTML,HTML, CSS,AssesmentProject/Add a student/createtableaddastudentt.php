<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studentdata";
// Create connection
$conn = new mysqli($servername, $username, 
                $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: "
	. $conn->connect_error);
} 
// sql to create table
$sql = "CREATE TABLE addastudentt(name VARCHAR(30),
	emailid	varchar(15),USN	varchar(9), PRIMARY KEY (USN)	
)";
if ($conn->query($sql) === TRUE) 
{
    echo " addastudentt Table created successfully";
} 
else 
{
    echo "Error in creating table: "
	. $conn->error;
}
$conn->close();
?>