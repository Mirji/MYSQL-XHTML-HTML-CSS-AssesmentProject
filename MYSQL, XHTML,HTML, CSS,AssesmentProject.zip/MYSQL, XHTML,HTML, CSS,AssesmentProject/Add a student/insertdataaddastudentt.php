<?php
$servername="localhost";
$username="root";
$password="";
$dbname = "studentdata";
//create connection
$conn = new mysqli ($servername, $username,$password,$dbname);
if($conn->connect_error)
{
die("Connection failed:"

.$conn->connect_error);
}
$sql="INSERT INTO addastudentt(name, emailid, USN)
VALUES('$_POST[name]',
'$_POST[emailid]',
'$_POST[USN]')";




if($conn->query($sql)===TRUE)
{
echo"New record created succesfully";
}
else
{
echo "Error:".$sql."<br>".$conn->error;
}
$conn->close();
?>
