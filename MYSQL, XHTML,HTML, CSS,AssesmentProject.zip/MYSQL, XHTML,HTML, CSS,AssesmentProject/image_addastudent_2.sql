-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 11, 2018 at 02:42 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `image`
--
CREATE DATABASE IF NOT EXISTS `studentdata` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `studentdata`;

-- --------------------------------------------------------

--
-- Table structure for table `addimg`
--

CREATE TABLE IF NOT EXISTS `addimg_addastudent_2` (
  `name` varchar(30) NOT NULL,`emailid` varchar(30) NOT NULL,`usn` varchar(30) NOT NULL,
  `pick` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addimg`
--

INSERT INTO `addimg_addastudent` (`name`,`emailid`,`usn`, `pick`) VALUES
('','','', 'addastudent/'),
('dee', 'addastudent/2017-03-29-10-31-09-132.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
