<?php
$servername="localhost";
$username="root";
$password="";
$dbname = "studentdata";
//create connection
$conn = new mysqli ($servername, $username,$password,$dbname);
if($conn->connect_error)
{
die("Connection failed:"

.$conn->connect_error);
}
$sql="INSERT INTO sem5marks1(USN,Name,MLM1,MLM2,MLA,BDAM1,BDAM2,BDAA,AVPM1,AVPM2,AVPA,IOTM1,IOTM2,IOTA,MADM1,MADM2,MADA)
VALUES('$_POST[USN]',
'$_POST[name]',
'$_POST[mlminor1]',
'$_POST[mlminor2]',
'$_POST[mlassign]',
'$_POST[bdaminor1]',
'$_POST[bdaminor2]',
'$_POST[bdaassign]',
'$_POST[ajminor1]',
'$_POST[ajminor2]',
'$_POST[ajassign]',
'$_POST[iotminor1]',
'$_POST[iotminor2]',
'$_POST[iotassign]',
'$_POST[madminor1]',
'$_POST[madminor2]',
'$_POST[madassign]')";




if($conn->query($sql)===TRUE)
{
echo"Marks assigned successfully succesfully";
}
else
{
echo "Error:".$sql."<br>".$conn->error;
}
$conn->close();
?>
