<?php 
include('dbcon.php');
if (isset($_POST['submit'])){
$filename=$_FILES["uploadfile"]["name"];
$tempname=$_FILES["uploadfile"]["tmp_name"];
$folder="student/".$filename;
move_uploaded_file($tempname,$folder);
$name=$_POST['name'];

mysql_query("insert into addimg(name,pick) values('$name','$folder')")or die(mysql_error());
 
}
?>	