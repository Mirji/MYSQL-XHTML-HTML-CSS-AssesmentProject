from django.conf.urls import url
from .import views

urlpatterns=[
    url(r"^studentregistration$",views.upload_student),
]