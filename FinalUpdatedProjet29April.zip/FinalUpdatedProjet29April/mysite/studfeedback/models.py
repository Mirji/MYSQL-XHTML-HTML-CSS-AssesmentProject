from django.db import models

# Create your models here.
class QuestionCategory(models.Model):
      questioncategory=models.CharField(max_length=100)

class feedbackquestion(models.Model):
    FeedbackQuestions=models.CharField(max_length=500)
    Status=models.CharField(max_length=50)
    QuestionCatID = models.ForeignKey('studfeedback.QuestionCategory',
                                   on_delete=models.CASCADE)

class Feedbackquestionchoices(models.Model):
    Feedbackqid=models.ForeignKey('studfeedback.feedbackquestion',
                                   on_delete=models.CASCADE)
    Feedbackchoice=models.CharField(max_length=200)
    Feedbackstatus=models.CharField(max_length=100)
    Feedbackmarks=models.IntegerField()

class Choices(models.Model):
    choice=models.CharField(max_length=100)
    cmarks=models.BigIntegerField()

class Choices1(models.Model):
    cmarks = models.IntegerField()
    choice=models.CharField(max_length=100)

class dataminingfeedback(models.Model):
    q1 = models.CharField(max_length=100)
    q2 = models.CharField(max_length=100)
    q3 = models.CharField(max_length=100)
    q4 = models.CharField(max_length=100)
    q5 = models.CharField(max_length=100)
    q6 = models.CharField(max_length=100)
    q7 = models.CharField(max_length=100)
    q8 = models.CharField(max_length=100)
    q9 = models.CharField(max_length=100)
    q10 = models.CharField(max_length=100)

class datamfeedback(models.Model):
    quechoices=models.CharField(max_length=100)
    quechoices = models.CharField(max_length=100)
    quechoices = models.CharField(max_length=100)
    quechoices = models.CharField(max_length=100)
    quechoices = models.CharField(max_length=100)
    quechoices = models.CharField(max_length=100)
    quechoices = models.CharField(max_length=100)
    quechoices = models.CharField(max_length=100)
    quechoices = models.CharField(max_length=100)
    quechoices = models.CharField(max_length=100)

class csharpfeedback(models.Model):
    q1 = models.CharField(max_length=100)
    q2 = models.CharField(max_length=100)
    q3 = models.CharField(max_length=100)
    q4 = models.CharField(max_length=100)
    q5 = models.CharField(max_length=100)
    q6 = models.CharField(max_length=100)
    q7 = models.CharField(max_length=100)
    q8 = models.CharField(max_length=100)
    q9 = models.CharField(max_length=100)
    q10 = models.CharField(max_length=100)
    q11 = models.CharField(max_length=100)
    q12 = models.CharField(max_length=100)

class csfeedback(models.Model):
    q1 = models.CharField(max_length=100)
    q2 = models.CharField(max_length=100)
    q3 = models.CharField(max_length=100)
    q4 = models.CharField(max_length=100)
    q5 = models.CharField(max_length=100)
    q6 = models.CharField(max_length=100)
    q7 = models.CharField(max_length=100)
    q8 = models.CharField(max_length=100)
    q9 = models.CharField(max_length=100)
    q10 = models.CharField(max_length=100)
    q11 = models.CharField(max_length=100)
    q12 = models.CharField(max_length=100)
    q13 = models.CharField(max_length=100)
    q14 = models.CharField(max_length=100)
    q15 = models.CharField(max_length=100)

class ccfeedback(models.Model):
    q1 = models.CharField(max_length=100)
    q2 = models.CharField(max_length=100)
    q3 = models.CharField(max_length=100)
    q4 = models.CharField(max_length=100)
    q5 = models.CharField(max_length=100)
    q6 = models.CharField(max_length=100)
    q7 = models.CharField(max_length=100)
    q8 = models.CharField(max_length=100)
    q9 = models.CharField(max_length=100)
    q10 = models.CharField(max_length=100)
    q11 = models.CharField(max_length=100)
    q12 = models.CharField(max_length=100)
    q13 = models.CharField(max_length=100)
    q14 = models.CharField(max_length=100)
    q15 = models.CharField(max_length=100)

class mtlrfeedback(models.Model):
    q1 = models.CharField(max_length=100)
    q2 = models.CharField(max_length=100)
    q3 = models.CharField(max_length=100)
    q4 = models.CharField(max_length=100)
    q5 = models.CharField(max_length=100)
    q6 = models.CharField(max_length=100)
    q7 = models.CharField(max_length=100)
    q8 = models.CharField(max_length=100)
    q9 = models.CharField(max_length=100)
    q10 = models.CharField(max_length=100)
    q11 = models.CharField(max_length=100)
    q12 = models.CharField(max_length=100)
    q13 = models.CharField(max_length=100)
    q14 = models.CharField(max_length=100)
    q15 = models.CharField(max_length=100)

class studentdetails(models.Model):
    name=models.CharField(max_length=100)
    usn=models.CharField(max_length=10)
    emailid = models.CharField(max_length=30)
    contactnumber = models.IntegerField()
    created = models.DateTimeField(auto_now_add=True)
    updated=models.DateTimeField(auto_now_add=True)

class facultydetails(models.Model):
    name=models.CharField(max_length=100)
    emailid = models.CharField(max_length=30)
    contactnumber = models.IntegerField()
    created = models.DateTimeField(auto_now_add=True)
    updated=models.DateTimeField(auto_now_add=True)










