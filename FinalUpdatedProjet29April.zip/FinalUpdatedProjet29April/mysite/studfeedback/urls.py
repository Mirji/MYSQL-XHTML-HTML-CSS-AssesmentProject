from django.conf.urls import url
from .import views

urlpatterns=[
url(r'uploadcategory/$',views.upload_category),
url(r'questionupload/$',views.upload_question),
url(r'uploadchoice/$',views.upload_choice),
url(r'uploadqchoices/$',views.uploadchoices),
url(r'fetchque/$',views.fetch_questions),
url(r'fetchform/$',views.fetch_questions2),
url(r'dataminingfeedback/$',views.datamining),
url(r'csharpfeedback/$',views.csharpfeedback),
url(r'csfeedback/$',views.csfeedback),
url(r'ccfeedback/$',views.ccfeedback),
url(r'mtlrfeedback/$',views.mtlrfeedback),
url(r'viewdmfeedback/$',views.view_dataminingfeedback),
url(r'viewdotnetfeedback/$',views.view_csharpfeedback),
url(r'viewcyberfeedback/$',views.view_cyberfeedback),
url(r'viewcloudfeedback/$',views.view_cloudfeedback),
url(r'viewfeedbackonmtlr/$',views.view_mtlrfeedback),
url(r'adminview/$',views.adminfeedbackview),
url(r'logindatamining/$',views.datamininglogin),
url(r'logincsharp/$',views.Csharplogin),
url(r'loginCS/$',views.CSlogin),
url(r'loginCC/$',views.CClogin),
url(r'loginMtlr/$',views.Mtlrlogin),
url(r'StudentPage/$',views.Studentdashboard),
url(r'AdminPage/$',views.Admindashboard),
url(r'home/$',views.homepage),
url(r"enrollment$", views.register_student),
url(r"Studentlogin$", views.StudentHome),
url(r"facultyenroll$", views.register_faculty)
]