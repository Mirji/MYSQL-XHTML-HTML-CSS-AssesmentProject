from django.shortcuts import render
from studfeedback.forms import Questioncatform
from studfeedback.forms import choiceform
from studfeedback.forms import Questionform
from studfeedback.models import QuestionCategory
from studfeedback.models import feedbackquestion
from django.http.response import HttpResponseRedirect
from studfeedback.forms import fchoicesform
from studfeedback.models import Choices1
from studfeedback.forms import Dataminingfeedbackform
from studfeedback.models import dataminingfeedback
from studfeedback.forms import csharpfeedbackform
from studfeedback.forms import csfeedbackform
from studfeedback.forms import ccfeedbackform
from studfeedback.forms import mtlrfeedbackform
from django.contrib.auth import authenticate,login
from studfeedback.forms import studentform
from department.models import Department
from studfeedback.forms import facultydetform
from django.contrib.auth import (
    authenticate,
    get_user_model
)


# Create your views here.
def upload_category(request):
    if request.method=='POST':

        category_form=Questioncatform(request.POST)
        if category_form.is_valid():
            post_category=category_form.save(commit=False)
            post_category.save()
            return HttpResponseRedirect('/studfeedback/uploadcategory')
    if request.method=='GET':
        return render(request, 'addcat.html')

def upload_question(request):
    if request.method=='GET':
        QuestionCatID=list(QuestionCategory.objects.all())
        return render(request,'addingquestion.html',
                      {'QuestionCategory':QuestionCatID})

    if request.method=='POST':
        fquestion_form=Questionform(request.POST)
        print(fquestion_form.errors)
        if fquestion_form.is_valid():
            post_question=fquestion_form.save(commit=False)
            post_question.QuestionCatID=QuestionCategory.objects.get(
                id =request.POST['QuestionCatID'])
            post_question.save()
            return HttpResponseRedirect('/studfeedback/questionupload')


def upload_choice(request):
    if request.method=='GET':
        Feedbackqid =list(feedbackquestion.objects.all())
        return render(request,'addqchoice.html',
                      {'feedbackquestion':Feedbackqid})

    if request.method=='POST':
        fchoice_form=choiceform(request.POST)
        print(fchoice_form.errors)
        if fchoice_form.is_valid():
            post_question=fchoice_form.save(commit=False)
            post_question.Feedbackqid=feedbackquestion.objects.get(
                id =request.POST['Feedbackqid'])
            post_question.save()
            return HttpResponseRedirect('/studfeedback/uploadchoice')

def uploadchoices(request):
    if request.method=='POST':

        feedchoice_form=fchoicesform(request.POST)
        if feedchoice_form.is_valid():
            post_feedchoices=feedchoice_form.save(commit=False)
            post_feedchoices.save()
            return HttpResponseRedirect('/studfeedback/uploadqchoices')
    if request.method=='GET':
        return render(request, 'addqchoices.html')

def fetch_questions(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        quechoices = list(Choices1.objects.all())
        return render(request,'feedbacksub.html',
                      {'feedbackquestion':questions,'Choices1':quechoices})

def datamining(request):
    if request.method=='POST':
        dmfeedbackform=Dataminingfeedbackform(request.POST)
        q1=request.POST.get('quechoices')
        q2 = request.POST.get('quechoices')
        q3 = request.POST.get('quechoices')
        q4 = request.POST.get('quechoices')
        q5 = request.POST.get('quechoices')
        q6 = request.POST.get('quechoices')
        q7 = request.POST.get('quechoices')
        q8 = request.POST.get('quechoices')
        q9 = request.POST.get('quechoices')
        q10 = request.POST.get('quechoices')
        if dmfeedbackform.is_valid():
            post_feedback=dmfeedbackform.save(commit=False)
            post_feedback.save('q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7', 'q8', 'q9', 'q10')
            return HttpResponseRedirect('/studfeedback/datamining')
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        quechoices = list(Choices1.objects.all())
        return render(request,'feedbacksub.html',
                      {'feedbackquestion':questions,'Choices1':quechoices})

def fetch_questions2(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        q1 = list(Choices1.objects.all())
        q2 = list(Choices1.objects.all())
        q3 = list(Choices1.objects.all())
        q4 = list(Choices1.objects.all())
        q5 = list(Choices1.objects.all())
        q6 = list(Choices1.objects.all())
        q7 = list(Choices1.objects.all())
        q8 = list(Choices1.objects.all())
        q9 = list(Choices1.objects.all())
        q10 = list(Choices1.objects.all())
        return render(request,'feedbacksubform2.html',
                      {'feedbackquestion':questions,'Choices1':q1,'Choices1':q2,'Choices1':q3,'Choices1':q4,'Choices1':q5,'Choices1':q6,'Choices1':q7,'Choices1':q8,'Choices1':q9,'Choices1':q10})

    if request.method == "POST":
        feedbackdm_form = Dataminingfeedbackform(request.POST)
        q1 = request.POST.get('q1')
        q2 = request.POST.get('q2')
        q3 = request.POST.get('q3')
        q4 = request.POST.get('q4')
        q5 = request.POST.get('q5')
        q6 = request.POST.get('q6')
        q7 = request.POST.get('q7')
        q8 = request.POST.get('q8')
        q9 = request.POST.get('q9')
        q10 = request.POST.get('q10')
        if feedbackdm_form.is_valid():
            post_dm = feedbackdm_form.save(commit=False)
            post_dm.save()
            return HttpResponseRedirect('/studfeedback/fetchform')

def csharpfeedback(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        q1 = list(Choices1.objects.all())
        q2 = list(Choices1.objects.all())
        q3 = list(Choices1.objects.all())
        q4 = list(Choices1.objects.all())
        q5 = list(Choices1.objects.all())
        q6 = list(Choices1.objects.all())
        q7 = list(Choices1.objects.all())
        q8 = list(Choices1.objects.all())
        q9 = list(Choices1.objects.all())
        q10 = list(Choices1.objects.all())
        return render(request,'csharpfeedbackform.html',
                      {'feedbackquestion':questions,'Choices1':q1,'Choices1':q2,'Choices1':q3,'Choices1':q4,'Choices1':q5,'Choices1':q6,'Choices1':q7,'Choices1':q8,'Choices1':q9,'Choices1':q10})

    if request.method == "POST":
        feedbackcsharp_form = csharpfeedbackform(request.POST)
        q1 = request.POST.get('q1')
        q2 = request.POST.get('q2')
        q3 = request.POST.get('q3')
        q4 = request.POST.get('q4')
        q5 = request.POST.get('q5')
        q6 = request.POST.get('q6')
        q7 = request.POST.get('q7')
        q8 = request.POST.get('q8')
        q9 = request.POST.get('q9')
        q10 = request.POST.get('q10')
        if feedbackcsharp_form.is_valid():
            post_csharp = feedbackcsharp_form.save(commit=False)
            post_csharp.save()
            return HttpResponseRedirect('/studfeedback/csharpfeedback')

def csfeedback(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        q1 = list(Choices1.objects.all())
        q2 = list(Choices1.objects.all())
        q3 = list(Choices1.objects.all())
        q4 = list(Choices1.objects.all())
        q5 = list(Choices1.objects.all())
        q6 = list(Choices1.objects.all())
        q7 = list(Choices1.objects.all())
        q8 = list(Choices1.objects.all())
        q9 = list(Choices1.objects.all())
        q10 = list(Choices1.objects.all())
        return render(request,'csfeedbackform.html',
                      {'feedbackquestion':questions,'Choices1':q1,'Choices1':q2,'Choices1':q3,'Choices1':q4,'Choices1':q5,'Choices1':q6,'Choices1':q7,'Choices1':q8,'Choices1':q9,'Choices1':q10})

    if request.method == "POST":
        feedbackcs_form = csfeedbackform(request.POST)
        q1 = request.POST.get('q1')
        q2 = request.POST.get('q2')
        q3 = request.POST.get('q3')
        q4 = request.POST.get('q4')
        q5 = request.POST.get('q5')
        q6 = request.POST.get('q6')
        q7 = request.POST.get('q7')
        q8 = request.POST.get('q8')
        q9 = request.POST.get('q9')
        q10 = request.POST.get('q10')
        if feedbackcs_form.is_valid():
            post_cs = feedbackcs_form.save(commit=False)
            post_cs.save()
            return HttpResponseRedirect('/studfeedback/csfeedback')

def ccfeedback(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        q1 = list(Choices1.objects.all())
        q2 = list(Choices1.objects.all())
        q3 = list(Choices1.objects.all())
        q4 = list(Choices1.objects.all())
        q5 = list(Choices1.objects.all())
        q6 = list(Choices1.objects.all())
        q7 = list(Choices1.objects.all())
        q8 = list(Choices1.objects.all())
        q9 = list(Choices1.objects.all())
        q10 = list(Choices1.objects.all())
        return render(request,'ccfeedbackform.html',
                      {'feedbackquestion':questions,'Choices1':q1,'Choices1':q2,'Choices1':q3,'Choices1':q4,'Choices1':q5,'Choices1':q6,'Choices1':q7,'Choices1':q8,'Choices1':q9,'Choices1':q10})

    if request.method == "POST":
        feedbackcc_form = ccfeedbackform(request.POST)
        q1 = request.POST.get('q1')
        q2 = request.POST.get('q2')
        q3 = request.POST.get('q3')
        q4 = request.POST.get('q4')
        q5 = request.POST.get('q5')
        q6 = request.POST.get('q6')
        q7 = request.POST.get('q7')
        q8 = request.POST.get('q8')
        q9 = request.POST.get('q9')
        q10 = request.POST.get('q10')
        if feedbackcc_form.is_valid():
            post_cc = feedbackcc_form.save(commit=False)
            post_cc.save()
            return HttpResponseRedirect('/studfeedback/ccfeedback')

def mtlrfeedback(request):
    if request.method=='GET':
        questions=list (feedbackquestion.objects.all())
        q1 = list(Choices1.objects.all())
        q2 = list(Choices1.objects.all())
        q3 = list(Choices1.objects.all())
        q4 = list(Choices1.objects.all())
        q5 = list(Choices1.objects.all())
        q6 = list(Choices1.objects.all())
        q7 = list(Choices1.objects.all())
        q8 = list(Choices1.objects.all())
        q9 = list(Choices1.objects.all())
        q10 = list(Choices1.objects.all())
        return render(request,'mtlrfeedbackform.html',
                      {'feedbackquestion':questions,'Choices1':q1,'Choices1':q2,'Choices1':q3,'Choices1':q4,'Choices1':q5,'Choices1':q6,'Choices1':q7,'Choices1':q8,'Choices1':q9,'Choices1':q10})

    if request.method == "POST":
        feedbackmtlr_form = mtlrfeedbackform(request.POST)
        q1 = request.POST.get('q1')
        q2 = request.POST.get('q2')
        q3 = request.POST.get('q3')
        q4 = request.POST.get('q4')
        q5 = request.POST.get('q5')
        q6 = request.POST.get('q6')
        q7 = request.POST.get('q7')
        q8 = request.POST.get('q8')
        q9 = request.POST.get('q9')
        q10 = request.POST.get('q10')
        if feedbackmtlr_form.is_valid():
            post_mtlr = feedbackmtlr_form.save(commit=False)
            post_mtlr.save()
            return HttpResponseRedirect('/studfeedback/mtlrfeedback')

def view_dataminingfeedback(request):
    if request.method == 'GET':
        dmfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_dataminingfeedback;"))
        return render(request, 'view_dataminingfeedback.html', {'dmfeedback': dmfeedback})

def view_csharpfeedback(request):
    if request.method == 'GET':
        cshpfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_csharpfeedback;"))
        return render(request, 'view_csharpfeedback.html', {'cshpfeedback': cshpfeedback})

def view_cyberfeedback(request):
    if request.method == 'GET':
        cyberfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_csfeedback;"))
        return render(request, 'view_cybersecurityfeedback.html', {'cyberfeedback': cyberfeedback})

def view_cloudfeedback(request):
    if request.method == 'GET':
        ccfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_ccfeedback;"))
        return render(request, 'view_cloudcomputingfeedback.html', {'ccfeedback': ccfeedback})

def view_mtlrfeedback(request):
    if request.method == 'GET':
        mtlrfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_mtlrfeedback;"))
        return render(request, 'viewmtlrfeedback.html', {'mtlrfeedback': mtlrfeedback})

def adminfeedbackview(request):
    if request.method == 'GET':
        dmfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_dataminingfeedback;"))
        cshpfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_csharpfeedback;"))
        cyberfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_csfeedback;"))
        ccfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_ccfeedback;"))
        mtlrfeedback = list(dataminingfeedback.objects.raw("SELECT * FROM studfeedback_mtlrfeedback;"))
        return render(request, 'adminallfeedbackview.html', {'mtlrfeedback': mtlrfeedback,'dmfeedback':dmfeedback,'cshpfeedback':cshpfeedback,'cyberfeedback':cyberfeedback,'ccfeedback':ccfeedback})

def datamininglogin(request):
    if request.method =='GET':
        return render(request,'logindm2.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/viewdmfeedback')
        else:
            return render(request, 'logindm2.html')

def Csharplogin(request):
    if request.method =='GET':
        return render(request,'logincsharp.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/viewdotnetfeedback')
        else:
            return render(request, 'logincsharp.html')

def CSlogin(request):
    if request.method =='GET':
        return render(request,'CSlogin.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/viewcyberfeedback')
        else:
            return render(request, 'CSlogin.html')

def CClogin(request):
    if request.method =='GET':
        return render(request,'CClogin.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/viewcloudfeedback')
        else:
            return render(request, 'CClogin.html')

def Mtlrlogin(request):
    if request.method =='GET':
        return render(request,'Mtlrlogin.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/viewfeedbackonmtlr')
        else:
            return render(request, 'Mtlrlogin.html')


def Studentdashboard(request):
    if request.method=='GET':
        return render(request, 'student2dashboard.html')

def Admindashboard(request):
    if request.method=='GET':
        return render(request, 'admindashboard.html')

def homepage (request):
    if request.method=='GET':
        return render (request, 'homiii.html')


def register_student(request):
    if request.method == "GET":
        return render(request, 'stud.html')


    if request.method == "POST":
        student_form = studentform(request.POST)
        if student_form.is_valid():
            post_student = student_form.save(commit=False)
            post_student.save()
            return HttpResponseRedirect('/studfeedback/enrollment')

def StudentHome(request):
    if request.method =='GET':
        return render(request,'Studentlogin.html')
    else:
        validate_user = authenticate(
            username=request.POST['username'],
            password=request.POST['password'])
        if validate_user:
            login(request, validate_user)
            return HttpResponseRedirect('/studfeedback/StudentPage')
        else:
            return render(request, 'logincsharp.html')

def register_faculty(request):
    if request.method == "GET":
        return render(request, 'facultyreg.html')


    if request.method == "POST":
        faculty_form = facultydetform(request.POST)
        if faculty_form.is_valid():
            post_student = faculty_form.save(commit=False)
            post_student.save()
            return HttpResponseRedirect('/studfeedback/facultyenroll')




