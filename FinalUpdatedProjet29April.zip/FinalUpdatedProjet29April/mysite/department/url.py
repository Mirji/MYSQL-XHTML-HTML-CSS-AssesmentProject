from django.conf.urls import url
from .import views

urlpatterns=[
    url(r'^$',views.upload_department),
    url(r'view/$',views.view_department),
    url(r'update/$',views.update_dept_acronym),
    url(r'addq/$',views.upload_question),
]