

from django import forms
from student.models import Student


class Studentform(forms.ModelForm):
    class Meta:
        model=Student
        fields=('name','usn','department')
