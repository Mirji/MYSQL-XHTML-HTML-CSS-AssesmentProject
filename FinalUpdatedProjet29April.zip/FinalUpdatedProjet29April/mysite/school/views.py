from django.shortcuts import render
from school.models import Student
from django.http import HttpResponse
# Create your views here.


def home(request):
   #Creating an entry
   objects = Student.objects.all().delete()
   student = Student(name = "Anupam", email = "anupam@journaldev.com",age = "24", website = "www.journaldev.com",section="A")
   student.save()
   student = Student(name = "Another", email = "another@journaldev.com",age = "21", website = "www.google.com")
   student.save()
   objects = Student.objects.all()
   res ='Printing all Students entries in the DB : <br>'

   for elt in objects:
       res += "Name: "+elt.name+"<br>"
       res += "Age: "+str(elt.age)+"<br>"
       res += "Section: "+elt.section+"<br>"
       res += "Section Full Name: "+elt.get_section_display()+"<br>"


   return HttpResponse(res)
