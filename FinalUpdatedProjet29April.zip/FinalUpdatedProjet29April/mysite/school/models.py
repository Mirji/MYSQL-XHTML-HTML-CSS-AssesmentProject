from django.db import models

# Create your models here.
class Student(models.Model):
    SECTION = (
        ('A', 'Alpha'),
        ('B', 'Beta'),
        ('C', 'Cappa'),
    )
    name = models.CharField(max_length=30)
    age = models.IntegerField()
    email = models.EmailField()
    website = models.URLField()
    section = models.CharField(max_length=1, choices=SECTION, default=SECTION[1][0])
