from django.apps import AppConfig


class StudentfeedbackConfig(AppConfig):
    name = 'studentfeedback'
