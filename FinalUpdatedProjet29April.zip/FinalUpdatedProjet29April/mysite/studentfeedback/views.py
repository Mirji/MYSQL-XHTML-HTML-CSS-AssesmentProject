from django.shortcuts import render
from department.forms import Departmentform
from django.http.response import HttpResponseRedirect
from department.forms import Questionform
from department.models import Department
from studentfeedback.forms import QuestionCatform
from studentfeedback.models import QuestionCategory
from studentfeedback.forms import FQuestionform

def upload_category(request):
    if request.method=='POST':
        category_form=QuestionCatform(request.POST)
        if category_form.is_valid():
            post_category=category_form.save(commit=False)
            post_category.save()
            return HttpResponseRedirect('/studentfeedback/uploadcat')
    if request.method=='GET':
        return render(request, 'add_questioncategory.html')


def upload_question(request):
    if request.method=='GET':
        QuestionCategoryID=list(QuestionCategory.objects.all())
        return render(request, 'add_newquestion.html')
    if request.method=='POST':
        question_form=FQuestionform(request.POST)
        if question_form.is_valid():
            post_category=question_form.save(commit=False)
            post_category.QuestionCatID = QuestionCategory.objects.get(
                QuestionCategoryID=request.POST['QuestionCategoryID'])
            post_category.save()
            return HttpResponseRedirect('/studentfeedback/uploadque')


